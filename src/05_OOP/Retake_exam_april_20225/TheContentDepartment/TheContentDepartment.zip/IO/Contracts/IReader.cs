﻿namespace TheContentDepartment.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
