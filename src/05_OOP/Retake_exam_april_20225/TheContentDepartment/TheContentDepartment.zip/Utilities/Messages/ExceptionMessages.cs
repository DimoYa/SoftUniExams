﻿namespace TheContentDepartment.Utilities.Messages
{
    public class ExceptionMessages
    {
        //Common
        public const string NameNullOrWhiteSpace = "Name cannot be null or whitespace.";
        public const string PathIncorrect = "{0} path is not valid.";
    }
}
