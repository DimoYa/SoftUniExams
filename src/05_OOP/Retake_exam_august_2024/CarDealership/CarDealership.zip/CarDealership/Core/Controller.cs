﻿using CarDealership.Core.Contracts;
using CarDealership.Models;
using CarDealership.Models.Contracts;
using CarDealership.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CarDealership.Core
{
    public class Controller : IController
    {
        private IDealership dealership;
        private string[] ALLOWED_INDIVIDUAL_MODELS = { "SaloonCar", "SUV" };
        private string[] ALLOWED_LEGAL_MODELS = { "SUV", "Truck" };

        public Controller()
        {
            dealership = new Dealership();
        }

        public string AddCustomer(string customerTypeName, string customerName)
        {
            ICustomer customer;

            switch (customerTypeName)
            {
                case "IndividualClient":
                    customer = new IndividualClient(customerName);
                    break;
                case "LegalEntityCustomer":
                    customer = new LegalEntityCustomer(customerName);
                    break;
                default:
                    return string.Format(OutputMessages.InvalidType, customerTypeName);
            }

            if (dealership.Customers.Exists(customerName))
            {
                return string.Format(OutputMessages.CustomerAlreadyAdded, customerName);
            }

            dealership.Customers.Add(customer);
            return string.Format(OutputMessages.CustomerAddedSuccessfully, customerName);
        }

        public string AddVehicle(string vehicleTypeName, string model, double price)
        {
            IVehicle vehicle;

            switch (vehicleTypeName)
            {
                case "SaloonCar":
                    vehicle = new SaloonCar(model, price);
                    break;
                case "SUV":
                    vehicle = new SUV(model, price);
                    break;
                case "Truck":
                    vehicle = new Truck(model, price);
                    break;
                default:
                    return string.Format(OutputMessages.InvalidType, vehicleTypeName);
            }

            if (dealership.Vehicles.Exists(model))
            {
                return string.Format(OutputMessages.VehicleAlreadyAdded, model);
            }

            dealership.Vehicles.Add(vehicle);
            return string.Format(OutputMessages.VehicleAddedSuccessfully, vehicleTypeName, model, vehicle.Price.ToString("F2"));
        }

        public string CustomerReport()
        {
            var report = new StringBuilder();
            report.AppendLine("Customer Report:");

            foreach (var customer in dealership.Customers.Models.OrderBy(c=> c.Name))
            {
                report.AppendLine(customer.ToString());
                report.AppendLine("-Models:");
                var vehicles = customer.Purchases.OrderBy(x=> x);

                if (!vehicles.Any())
                {
                    report.AppendLine("--none");
                }
                else
                {
                    vehicles.OrderBy(x=> x).ToList().ForEach(x => report.AppendLine($"--{x}"));
                }
            }

            return report.ToString().TrimEnd();
        }

        public string PurchaseVehicle(string vehicleTypeName, string customerName, double budget)
        {
            if (!dealership.Customers.Exists(customerName))
            {
                return string.Format(OutputMessages.CustomerNotFound, customerName);
            }

            if (!dealership.Vehicles.Models.Select(x=> x.GetType().Name).Contains(vehicleTypeName))
            {
                return string.Format(OutputMessages.VehicleTypeNotFound, vehicleTypeName);
            }

            var customer = dealership.Customers.Get(customerName);

            if ((customer.GetType().Name == "IndividualClient" && !ALLOWED_INDIVIDUAL_MODELS.Contains(vehicleTypeName)) ||
                (customer.GetType().Name == "LegalEntityCustomer" && !ALLOWED_LEGAL_MODELS.Contains(vehicleTypeName)))
            { 
                return string.Format(OutputMessages.CustomerNotEligibleToPurchaseVehicle, customerName, vehicleTypeName);
            }

            var availableVehicles = dealership.Vehicles.Models.Where(x => x.GetType().Name == vehicleTypeName);
            var possibleToPurchase = false;

            foreach (var availableVehicle in availableVehicles)
            {
                if (budget >= availableVehicle.Price)
                {
                    possibleToPurchase = true;
                    break;
                }
            }

            if (!possibleToPurchase)
            {
                return string.Format(OutputMessages.BudgetIsNotEnough, customerName, vehicleTypeName);
            }

            var mostAffordableVehicle = availableVehicles
                .Where(v=> v.Price <= budget).ToList()
                .OrderByDescending(v=> v.Price)
                .FirstOrDefault();


            mostAffordableVehicle.SellVehicle(customerName);
            customer.BuyVehicle(mostAffordableVehicle.Model);

            return string.Format(OutputMessages.VehiclePurchasedSuccessfully, customerName, mostAffordableVehicle.Model);
        }

        public string SalesReport(string vehicleTypeName)
        {
            var report = new StringBuilder();

            report.AppendLine($"{vehicleTypeName} Sales Report:");

            var filteredVehicles = dealership.Vehicles.Models
                .Where(m => m.GetType().Name == vehicleTypeName);

            foreach (var vehicle in filteredVehicles.OrderBy(x=> x.Model))
            {
                report.AppendLine(vehicle.ToString());
            }

            report.AppendLine($"-Total Purchases: {filteredVehicles.Sum(x=> x.SalesCount)}");
            
            return report.ToString().TrimEnd();
        }
    }
}
